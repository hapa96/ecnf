﻿'--------------------------------------------------------------------------
' 
'  Copyright (c) Microsoft Corporation.  All rights reserved. 
' 
'  File: AssemblyInfo.vb
'
'--------------------------------------------------------------------------

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("VisualizePartitioning")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("Microsoft Corporation")>
<Assembly: AssemblyProduct("VisualizePartitioning")>
<Assembly: AssemblyCopyright("Copyright © Microsoft Corporation.  All rights reserved.")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>
<Assembly: ComVisible(False)>
<Assembly: Guid("4536aadc-3ba4-4eb0-8278-9b0d32be925d")>
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
