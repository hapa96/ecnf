﻿'--------------------------------------------------------------------------
' 
'  Copyright (c) Microsoft Corporation.  All rights reserved. 
' 
'  File: AssemblyInfo.cs
'
'--------------------------------------------------------------------------

Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("AcmePizza")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("Microsoft Corporation")>
<Assembly: AssemblyProduct("AcmePizza")>
<Assembly: AssemblyCopyright("Copyright © Microsoft Corporation.  All rights reserved.")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>
<Assembly: ComVisible(False)>
<Assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)>
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
