﻿//--------------------------------------------------------------------------
// 
//  Copyright (c) Microsoft Corporation.  All rights reserved. 
// 
//  File: App.xaml.cs
//
//--------------------------------------------------------------------------

using System.Windows;

namespace NBodySimulation
{
    /// <summary>Interaction logic for App.xaml</summary>
    public partial class App : Application
    {
    }
}
