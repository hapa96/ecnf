These images came from the Microsoft Office Online Clip Art gallery:
http://office.microsoft.com/clipart/preview.aspx?AssetID=MPj0402207
http://office.microsoft.com/clipart/preview.aspx?AssetID=MPj0406659