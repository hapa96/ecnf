﻿'--------------------------------------------------------------------------
' 
'  Copyright (c) Microsoft Corporation.  All rights reserved. 
' 
'  File: AssemblyInfo.vb
'
'--------------------------------------------------------------------------

Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("EditDistance")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("EditDistance")>
<Assembly: AssemblyCopyright("Copyright © Microsoft Corporation.  All rights reserved.")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>
<Assembly: ComVisible(False)>
<Assembly: Guid("24642501-cf24-4734-97e5-d8e82c379657")>
<Assembly: AssemblyVersion("1.2.0.0")>
<Assembly: AssemblyFileVersion("1.2.0.0")>