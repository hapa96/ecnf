﻿using System;
using System.Diagnostics;

namespace Parallelism
{
    class Program
    {
        static void Main()
        {
            int[] rangeValues = {20, 200, 2000, 20000, 200000, 2000000};
            Func<int, int[]> calculatePrime;

            // just activate the calculation methode of your choice
            calculatePrime = CalculatePrimesDemo.CalculatePrimesSequential;
            //calculatePrime = CalculatePrimesDemo.CalculatePrimesThreads;
            //calculatePrime = CalculatePrimesDemo.CalculatePrimesParallelFor;
            // calculatePrime = CalculatePrimesDemo.CalculatePrimesLinq;
            // calculatePrime = CalculatePrimesDemo.CalculatePrimesPLinq;

            foreach (var rangeValue in rangeValues)
            {
                var stopWatch = new Stopwatch();
                stopWatch.Start();

                var primes = calculatePrime(rangeValue);
                Console.WriteLine($"Range [3..{rangeValue}]: {stopWatch.ElapsedMilliseconds}ms");
//                PrintPrimes(primes);
            }

            Console.WriteLine("Done.");
            Console.ReadKey();
        }

        public static void PrintPrimes(int[] primes)
        {
            foreach (var i in primes)
                Console.WriteLine(i);
        }

    }
}
