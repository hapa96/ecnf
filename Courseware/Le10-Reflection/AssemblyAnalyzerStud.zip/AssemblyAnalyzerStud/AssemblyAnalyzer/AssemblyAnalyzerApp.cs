﻿using System;
using System.IO;
using System.Reflection;

namespace AssemblyAnalyzer
{
    public enum TypesToPrint
    {
        None       = 0x00,
        Classes    = 0x01,
        Interfaces = 0x02,
        Any        = 0xff
    }

    class AssemblyAnalyzerApp
    {
        static void Main(string[] args)
        {
            string argString = String.Join(" ", args);
            TypesToPrint type = GetTypeArg(argString);
            bool method = GetMethodArg(argString);
            string assemblyDir = GetAssemblyDirArg(argString);

            // TODO: load assembly first
            var assembly = Assembly.LoadFrom("the assembly name to load");

            // this method handles all analysis
            PrintTypes(assembly, type, method);

            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }

        private static TypesToPrint GetTypeArg(string argString)
        {
            if (argString.Contains("-t I"))
            {
                return TypesToPrint.Interfaces;
            }
            else if (argString.Contains("-t C"))
            {
                return TypesToPrint.Classes;
            }

            return TypesToPrint.Any;
        }

        private static bool GetMethodArg(string argString)
        {
            if (argString.ToLower().Contains("-m true"))
            {
                return true;
            }

            return false;
        }

        private static string GetAssemblyDirArg(string argString)
        {
            string assembly = ".";
            try
            {
                int index = argString.IndexOf("-f");
                if (index > 0)
                {
                    assembly = argString.Substring(index + 3, argString.Length - index - 3);
                }
            }
            catch (Exception e)
            {
                // use default dll
                assembly = ".";
            }

            return assembly.Trim();

        }

        static public void PrintTypes(Assembly assembly, TypesToPrint typesToPrint, bool printMethods)
        {
            // TODO: Do the assembly analysis
        }
    }
}
