﻿using System;
using System.Diagnostics;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;

namespace FactorialCalculation
{
    delegate O Calcin< in I, O>(I input);

    class Program
    {
        static Stopwatch stopWatch = new Stopwatch();
        public static void Main()
        {

            long factorialInput = 1000L;
            int loops = 1;

            Dummy();

            EvaluateFactorialCalculation(loops, factorialInput, FactStaticTyped);

            EvaluateFactorialCalculation(loops, factorialInput, new Func<dynamic, dynamic>(FactDynamicTyped));

            EvaluateFactorialCalculation(loops, factorialInput, FactPythonScript);

            Console.WriteLine("Press any key to finish");
            Console.ReadKey();
        }

        private static void EvaluateFactorialCalculation<I, O>(int loops, I factorialInput, Func<I, O> factorialMethod)
        {
            Console.WriteLine("{0,10}", factorialMethod.Method.Name);
            for (int i = 0; i < loops; i++)
            {
                // Get the elapsed time as a TimeSpan value.
                stopWatch.Restart();
                O result = factorialMethod(factorialInput);
//                Console.WriteLine($"Result: {result:E10}: Time: {stopWatch.ElapsedTicks,10}");
                Console.WriteLine($"Time: {stopWatch.ElapsedTicks,10}");
            }
        }

        static object FactPythonScript(long factorialInput)
        {
            return 0;
        }

        static long FactStaticTyped(long n)
        {

            return 0;
        }

        static dynamic FactDynamicTyped(dynamic n)
        {
            return 0;
        }

        static void GetExpressionTree()
        {
            Func<long, long> function = FactStaticTyped;
            Func<dynamic, dynamic> functionDyn = FactDynamicTyped;

            Func<long, long> expression = function;
            expression(1);

        }

        static void Dummy()
        {
            Console.WriteLine("Hello");
        }
    }
}
