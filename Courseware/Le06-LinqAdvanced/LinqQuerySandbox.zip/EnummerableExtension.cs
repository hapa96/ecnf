﻿using System;
using System.Collections.Generic;

namespace LinqQuerySandbox
{
    public static class EnummerableExtension
    {
    }
}
