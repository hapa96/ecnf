﻿namespace LinqQuerySandbox
{
    public class Car
    {
        public string Model { get; set; }
        public string Color { get; set; }
    }
}
