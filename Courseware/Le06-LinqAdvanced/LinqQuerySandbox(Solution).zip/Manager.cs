﻿namespace LinqQuerySandbox
{
    public class Manager : Person
    {

    }
}
